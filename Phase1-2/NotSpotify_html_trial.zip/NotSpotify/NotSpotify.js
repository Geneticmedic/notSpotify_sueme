const song = document.getElementById('song');
const prev = document.getElementById('prev');
const play = document.getElementById('play');
const next = document.getElementById('next');
let trackIndex = 0;

const tracks = [
    {
        title: 'Cant Help Falling in Love',
        artist: 'Elvis Presley',
        coverPath: 'cover1.jpg',
        songPath: 'music1.mp3',
        duration: '3:00',
    },
    {
        title: 'Cant Help Falling in Love',
        artist: 'Elvis Presley',
        coverPath: 'cover1.jpg',
        songPath: 'music1.mp3',
        duration: '3:00',
    }
];


loadSong(tracks[trackIndex]);

function loadSong(track) {
    cover.src = track.coverPath;
    song.src = track.songPath;
    title.textContent = track.title;
    duration.textContent = track.duration;
}


function playPauseMedia() {
    if (song.paused) {
        song.play();
    } else {
        song.pause();
    }
}

function updatePlayPauseIcon() {
    if (song.paused) {
        play.classList.remove('fa-pause');
        play.classList.add('fa-play');
    } else {
        play.classList.remove('fa-play');
        play.classList.add('fa-pause');
    }
}


function updateProgress() {
    progress.style.width = (song.currentTime / song.duration) * 100 + '%';
    let minutes = Math.floor(disc.currentTime / 60);
    let seconds = Math.floor(disc.currentTime % 60);
    if (seconds < 10) {
        seconds = '0' + seconds;
    }
    timer.textContent = `${minutes}:${seconds}`;
}

play.addEventListener('click', playPauseMedia);

disc.addEventListener('play', updatePlayPauseIcon);
disc.addEventListener('pause', updatePlayPauseIcon);
disc.addEventListener('ended', gotoNextSong.bind(null, true));

prev.addEventListener('click', gotoPreviousSong);

next.addEventListener('click', gotoNextSong.bind(null, false));
const audio = document.getElementById('audio');
const img = document.querySelector('img');
const name = document.getElementById("name");
const artist = document.getElementById("artistName");

const prev = document.getElementById('prev');
const play = document.getElementById('play');
const next = document.getElementById('next');

const tracks = [
    {
		path: 'music1'
        name: 'Cant Help Falling in Love',
        artist: 'Elvis Presley',
    },
    {
		path: '1'
        name: '1',
        artist: '1',
    },
	{
		path: '2'
        name: '2',
        artist: '2',
    },
	{
		path: '3'
        name: '3',
        artist: '3',
    }
];
//let trackIndex = 0;
//loadSong(tracks[trackIndex]);

let playing = false;

const Play= () => {
    playing = true;
    audio.play();
    play.classList.replace("fa-play", "fa-pause");
};

const Pause = () => {
    playing = false;
    audio.pause();
    play.classList.replace("fa-pause", "fa-play");
};

//play/pause button
play.addEventListener("click", ()=>{
    playing ? Pause() : Play();
});

const Load = (tracks) => {
    name.textContent = tracks.name;
    artist.textContent = tracks.artist;
    audio.src = "music/"+tracks.path+".mp3";
    img.src = "img/"+tracks.path+".jpg";
}

playlist = 0;
const Next = () => {
    playlist = (playlist+1)%tracks.length;
    Load(tracks[playlist]);
    Play();
};

const Prev = () => {
    playlist = (playlist-1+tracks.length)%tracks.length;
    Load(tracks[playlist]);
    Play();
}

next.addEventListener("click", Next);
prev.addEventListener("click", Prev);